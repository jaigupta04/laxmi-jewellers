import StoreRouter from './store-router';

export default StoreRouter;
