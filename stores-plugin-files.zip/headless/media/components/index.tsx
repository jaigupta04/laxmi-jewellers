export { WixMediaImage } from '@wix/media/components';
